import { test, expect, chromium, BrowserContext, Locator } from '@playwright/test';
let sony3DHomePageURL = 'https://prjb-frontend-webapp-b9awavg3bvgbfzfg.japaneast-01.azurewebsites.net/';
let sonyLoginPageURL = 'https://prjb-frontend-webapp-b9awavg3bvgbfzfg.japaneast-01.azurewebsites.net/#/login';
const clientId = '926493967338-lhuomres69q6coji1ojsjpse2mr27oa1.apps.googleusercontent.com';
const clientSecret = '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';
const redirectUri = 'https://prjb-frontend-webapp-b9awavg3bvgbfzfg.japaneast-01.azurewebsites.net/';
const authorizationEndpoint = 'https://accounts.google.com/o/oauth2/v2/auth';
const tokenEndPoint = 'https://oauth2.googleapis.com/token';

test('Verify end to end scenarios', async ({ page }) => {
    
    await page.goto(sony3DHomePageURL);
    await page.waitForURL(sony3DHomePageURL);
    const homePageURL = page.url();
    console.log("Sony 3D Creation Home Page URL::= " + homePageURL);
    expect(homePageURL).toBe(sony3DHomePageURL);
    //await expect(page).toHaveTitle('Project B');
    const loginButton:Locator=await page.getByRole('button', { name: 'Log in' });  
    await expect(loginButton).toBeVisible();
    //Click on Login Button
    await loginButton.click();
    const expectedLoginURL = sonyLoginPageURL;
    const currentLoginURL = page.url();
    console.log("Sony 3D Login URL::= ", currentLoginURL);
    expect(currentLoginURL).toBe(expectedLoginURL);
    await page.setExtraHTTPHeaders({
        'accept-language' : 'en-US,en;q=0.9,hy=0.8'
 
    });
 
    await page.evaluate(()=>{
        localStorage.setItem('authToken','eyJhbGciOiJSUzI1NiIsImtpZCI6ImZhMDcyZjc1Nzg0NjQyNjE1MDg3YzcxODJjMTAxMzQxZTE4ZjdhM2EiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MjY0OTM5NjczMzgtbGh1b21yZXM2OXE2Y29qaTFvanNqcHNlMm1yMjdvYTEuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MjY0OTM5NjczMzgtbGh1b21yZXM2OXE2Y29qaTFvanNqcHNlMm1yMjdvYTEuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTEzOTM3MjE0MzY3MzQzMDk3MjEiLCJlbWFpbCI6ImdheWF0aHJpdGVzdGVyNUBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6IlUwZ21qNXlBQWl2clhKdV9zMGYxOWciLCJuYW1lIjoiZ2F5YXRocmkgdGVzdGVyIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0w3eElTTnRXak9QMXUxNFV0dkNBU1M1SjZ2Y1A3aGY4SW9qanNMVl9Lb1NHRnZ1dz1zOTYtYyIsImdpdmVuX25hbWUiOiJnYXlhdGhyaSIsImZhbWlseV9uYW1lIjoidGVzdGVyIiwiaWF0IjoxNzM4MTM5MTIzLCJleHAiOjE3MzgxNDI3MjN9.dX_AQxMGgjs6TDYMYwg9ENCxxs3gxkx1YcaV_lRXje5JVvkjBBUJhHyByugq3UvQ-u9InzIvwgJaY-OB0VSlKiDOA0cR0tsv05f0ogMIQDrgu5yS3tLkKSnCoFXt7VULJhd1mwa85bmj2lvDaHXUPINA6V0nde5yiTgzQnqEMAZAh8-STLh6Bpsaw1ajJKfiJZM7eax-0vCeIqjLvnkEuJbMzwpKF51s-7YNrYuxh7J7sBIdClwxp_NY1sJJsHGa9Hjs8zAAoOBmDXU7aRLzhpwv0EFSsOhraLZIzxq9GEonIWZ0idO6gvmGNE_J4HyW1yjzZSIsOyT9LtIheruxrg')
        localStorage.setItem("loggedIn",true);
        localStorage.setItem('tokenExpiration', '1738142722634');
        localStorage.setItem('refreshToken', '1//0gCrGKJ1cJs4TCgYIARAAGBASNwF-L9Ir9rqheFNrmkUECxATCvWwFCAodgY2fQSRrVlLagh4JEx4kRR-SoUGtFVeikvAPDXQk9A');
    });
 
 
    let bearerToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjJjOGEyMGFmN2ZjOThmOTdmNDRiMTQyYjRkNWQwODg0ZWIwOTM3YzQiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI5MDI1ODM3MTAwMDctcnZxMTljZ3A2OTBvOWE0cGpsZjhrcnBqMjBhYnBlYWkuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDA1Mzg3MDQxMjI5OTU4MjQyMTUiLCJlbWFpbCI6InN1bmlsc2RldDIwMTJAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJaX0tFenJqSHZqU1YyMXNJXzV3LU9BIiwibmFtZSI6IlN1bmlsIEthbmF1amlhIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lvUE5tVzlPdGZGN1pFdlQzekhYblpGOTAzZDFKU1lhUk12ME1IWHctSnJCNVVJQT1zOTYtYyIsImdpdmVuX25hbWUiOiJTdW5pbCIsImZhbWlseV9uYW1lIjoiS2FuYXVqaWEiLCJpYXQiOjE3MzM4NDgyMTYsImV4cCI6MTczMzg1MTgxNn0.tmjHbkW5QJkg1wjcrg5-Yi9fifYozjzvruobhmro-1V6FxAzf4ym4sqKDH3mU_OydoT-RaExJh9Oc6xNO0m6r4Fepqqa-PvxCmVeyJGZ5uD6AcfGKKQ1MmSdybNlKWRCxu654pUU4HnGLNVgJqInZVQK-FPbHBs46GGVUdtecEPqKTb6SgEo5gMfEwRGHnMf41_I-3djXTliSLC3FxD75YV5Y9O-734dLIfrYYmGkL12VDuGKXQkK0b8GEl98rm2CnesrzGXQTmgI2H7Gr1TUZD0dv59KhlW5O-yEIYGhBUaQXnPB8DR8WFUXvuWOGnOnM_jqqfw7p3eJF1yTKIntQ'
 
    page.on('route' , (route,request)=>{
         const modifieldHeaders = {
             ...request.headers(),
             'Authorization':`Bearer ${bearerToken}`
         }
         route.continue({headers:modifieldHeaders})
     });
     let homeUrl="https://prjb-frontend-webapp-b9awavg3bvgbfzfg.japaneast-01.azurewebsites.net/#/home";
 
     //https://prjb-frontend-webapp-b9awavg3bvgbfzfg.japaneast-01.azurewebsites.net/#/home
     await page.goto(homeUrl);

 await page.waitForURL(homeUrl);

 console.log("Home page URL ==",homeUrl);
 //const uploadButton=await page.click("//button[@class='MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-1ct15v9'] ");
 

const uploadSelectImages = page.locator('//input[@id="file-input"]');
const multipleImagesPaths = [
    './tests/ImagesToUpload/0001.jpg',
    './tests/ImagesToUpload/0002.jpg',
    './tests/ImagesToUpload/0003.jpg',
    './tests/ImagesToUpload/0004.jpg',
    './tests/ImagesToUpload/0005.jpg',
    './tests/ImagesToUpload/0006.jpg',
    './tests/ImagesToUpload/0007.jpg',
    './tests/ImagesToUpload/0008.jpg',
    './tests/ImagesToUpload/0009.jpg',
    './tests/ImagesToUpload/00010.jpg',
    './tests/ImagesToUpload/00011.jpg',
    './tests/ImagesToUpload/00012.jpg',
    
]
await uploadSelectImages.setInputFiles(multipleImagesPaths,{ timeout: 50000 });
await page.waitForTimeout(10000);
// const uploadButton = page.locator('//button[@class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-1ct15v9"]');
//  await uploadButton.waitFor({ state: 'visible' });
//  expect(uploadButton).toBeVisible();{ timeout: 50000 })
//  await uploadButton.click();
 if (uploadSelectImages) {
    console.log(" uploadSelectImages is clicked successfully.")
} else {
    console.error(" uploadSelectImages is not clicked successfully.")
}

const getprogress=page.locator('//p[(text()="In Progress")]');
console.error(getprogress);

const projectid=page.locator(('//img[@alt="Project_202501292301"])[1]');
projectid.click();
console.error(projectid);



// // const uploadButton = page.locator('//button[@class="MuiButtonBase-root MuiIconButton-root MuiIconButton-sizeMedium css-1ct15v9"]');
// // await uploadButton.waitFor({ state: 'visible' });
// // expect(uploadButton).toBeVisible();
// // await uploadButton.click();
// // if (uploadButton) {
// //     console.log("upload Button is clicked successfully.")
// // } else {
// //     console.error("upload Button is not clicked successfully.")
// // }

// // });

// // test('Verify image upload popup', async ({ page }) => {

// //     let homeUrl="https://prjb-frontend-webapp-b9awavg3bvgbfzfg.japaneast-01.azurewebsites.net/#/home";
// //     await page.locator('div').filter({ hasText: /^Drop your images\.\.\.$/ }).click();
// //    // const dropimage=await page.locator("//p[@class='MuiTypography-root MuiTypography-body2 css-17ot39s']");
// //     await page.waitForTimeout(60000);
// //    // dropimage.click();



});