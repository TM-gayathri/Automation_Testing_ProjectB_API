import { test, expect } from '@playwright/test';
import sonyLogoJsonFile from './testData/loginPageData/sonyLogo.json';
import sonyXYZCreationSuiteJsonFile from './testData/loginPageData/sonyXYZCreationSuite.json';
import loginImageJsonFile from './testData/loginPageData/loginImage.json';
import welcomeImageJsonFile from './testData/loginPageData/welcomeImage.json';
import welcomeMessageJsonFile from './testData/loginPageData/welcomeImageMessage.json';
import userNameJsonFile from './testData/loginPageData/userNamefield.json';
import passwordJsonFile from './testData/loginPageData/passwordfield.json';
import loginDesableButtonJsonFile from './testData/loginPageData/loginButtonDesable.json';
import signInWithGoogleButtonJsonFile from './testData/loginPageData/signInWithGoogle.json';


const sony3DHomePageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/';
const sonyLoginPageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/#/login';


test('Verify Sony 3D Login Web Page URL And Title', async ({ page }) => {

  await page.goto(sony3DHomePageURL);
  await page.waitForURL(sony3DHomePageURL);
  const homePageURL = page.url();
  console.log("Sony 3D Creation Home Page URL::= "+homePageURL);
  expect(homePageURL).toBe(sony3DHomePageURL);

  const imageSelector = '#root > div > header > img';
  await page.waitForSelector(imageSelector,{ state: 'visible' });
  await expect(page).toHaveTitle('XYZ Capture');
  const loginButton = page.getByRole('button',{name:'Login'});
  await expect(loginButton).toBeVisible();
  const loginButtonBoundingBox = await loginButton.boundingBox();
  const loginbuttonWidth = loginButtonBoundingBox?.width;
  const loginbuttonHeight = loginButtonBoundingBox?.height;
  if(loginButtonBoundingBox) {
    console.log("Sony Login Button Dimentions:: ");
    console.log("Sony Login Button Dimentions Width::=",loginbuttonWidth);
    console.log("Sony Login Button Dimentions Height::=",loginbuttonHeight);

  }
  await loginButton.click();
  const expectedLoginURL = sonyLoginPageURL;
  const currentLoginURL = page.url();
  console.log("Sony 3D Login URL::= ",currentLoginURL);
  expect(currentLoginURL).toBe(expectedLoginURL);


});
test('Verify XYZ All Tabs [Top, Product,App & Service,SDK,Whats New] is Showing in Sony 3D Login WebPage And logo Dimensions', async ({ page }) => {
  await page.goto(sonyLoginPageURL);
  
  await expect(page.getByText('Top')).toBeVisible();
  await expect(page.getByRole('list')).toContainText('Top');

  await expect(page.getByText('Product')).toBeVisible();
  await expect(page.getByRole('list')).toContainText('Product');

  await expect(page.locator('#selected')).toContainText('App & Service');
  
  await expect(page.getByText('SDK')).toBeVisible();
  await expect(page.getByRole('list')).toContainText('SDK');
  const lastTab = "What's New";
  await expect(page.getByText(lastTab)).toBeVisible();
  await expect(page.getByRole('list')).toContainText('What\'s New');

  const homepageTabList = await page.locator('.wrapper > ul');
  const tabs = await homepageTabList.locator('li');
  const tabCount = await tabs.count();
  console.log("Home Page Tabs Count ::=",tabCount);
  expect(tabCount).toBe(5);

  const expectedTabs = ['Top','Product','App & Service','SDK','What\'s New'];
  for(let i =0; i<tabCount; i++) {
    const tabText = await tabs.nth(i).textContent();
    expect(tabText?.trim()).toBe(expectedTabs[i]);

   
  }
  

}); 

test('Verify Sony Logo is Showing in Sony 3D Login Web Page And Sony Logo Dimentions', async ({ page }) => {
  const sonyLogoData = sonyLogoJsonFile;
  console.log('read Json data::=', sonyLogoData);
  await page.goto(sonyLoginPageURL);
  const sonyLogoExists = page.locator('//header//img[@alt="logo"]');
  const isSonyLogoVisible = await sonyLogoExists.isVisible();
 if(isSonyLogoVisible) {
  console.log('Sony Logo is visible on the Login Page');
 } else{
  console.log('Sony Logo is not visible on the Login Page');
 }

  const imgSrc = await sonyLogoExists.getAttribute("src");
  console.log("Image Source URL:: ",imgSrc);
  if(imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
    console.log("Sony Logo URL is Showing");
  } else {
    console.log("Sony Logo URL is Not Showing");
  }
  const sonyLogoBoundingBox = await sonyLogoExists.boundingBox();
  console.log("Sony Logo Bounding BOX::=", sonyLogoBoundingBox);
  const sonyLogoWidth = sonyLogoBoundingBox?.width;
  const sonyLogoHeight = sonyLogoBoundingBox?.height;
  console.log("Sony Logo Dimentions Width::=", sonyLogoWidth);
  console.log("Sony Logo Dimentions Height::=", sonyLogoHeight);

  await expect(sonyLogoWidth).toBe(sonyLogoData.width);
  await expect(sonyLogoHeight).toBe(sonyLogoData.height);
  if (sonyLogoBoundingBox) {
    console.log("Sony Logo Dimentions::= ");
    console.log("Sony Logo Dimentions Width::=", sonyLogoWidth);
    console.log("Sony Logo Dimentions Height::=", sonyLogoHeight);

  } else {
    console.log("Sony Logo is not visible or not Loaded");
  }

  const fontcolor = await sonyLogoExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);

  await expect(fontcolor.fontFamily).toBe(sonyLogoData.fontFamily);
  await expect(fontcolor.fontSize).toBe(sonyLogoData.fontSize);
  await expect(fontcolor.color).toBe(sonyLogoData.color);
});

test('Verify XYZ Creation Suite logo is Showing in Sony 3D login Web Page And XYZ Creation Suite logo Dimension', async ({ page }) => {
  
  const sonyXYZCreationSuiteImageData = sonyXYZCreationSuiteJsonFile;
  console.log('read Json data::=', sonyXYZCreationSuiteImageData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();

  const xyzCreationSuiteTextExists = page.locator('//span[@class="heading" and text()= "XYZ Creation Suite"]');
  const xyzCreationSuiteTextBoundingBox = await xyzCreationSuiteTextExists.boundingBox();
  console.log("Sony XYZ Creation Suite Bounding Box Dimentions::=", xyzCreationSuiteTextBoundingBox);
  const sonyXYZCreationSuiteImageWidth = xyzCreationSuiteTextBoundingBox?.width;
  const sonyXYZCreationSuiteImageHeight = xyzCreationSuiteTextBoundingBox?.height;
  console.log("Sony XYZ Creation Suite Dimentions Width::=", sonyXYZCreationSuiteImageWidth);
    console.log("Sony XYZ Creation Suite Dimentions Height::=", sonyXYZCreationSuiteImageHeight);

  await expect(sonyXYZCreationSuiteImageWidth).toBe(sonyXYZCreationSuiteImageData.width);
  await expect(sonyXYZCreationSuiteImageHeight).toBe(sonyXYZCreationSuiteImageData.height);

  if (xyzCreationSuiteTextBoundingBox) {
    console.log("Sony XYZ Creation Suite Text Dimentions:: ");
    console.log("Sony XYZ Creation Suite Dimentions Width::=", xyzCreationSuiteTextBoundingBox.width);
    console.log("Sony XYZ Creation Suite Dimentions Height::=", xyzCreationSuiteTextBoundingBox.height);

  } else {
    console.log("Sony XYZ Creation Suite is not visible or not Loaded");
  }
  const fontcolor = await xyzCreationSuiteTextExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(sonyXYZCreationSuiteImageData.fontFamily);
  await expect(fontcolor.fontSize).toBe(sonyXYZCreationSuiteImageData.fontSize);
  await expect(fontcolor.color).toBe(sonyXYZCreationSuiteImageData.color);



});  




test('Verify Login WebPage Image And Image Dimensions',async({page}) => {

  const loginImageData = loginImageJsonFile
  console.log('read Json data::=', loginImageData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();

  const loginPageImageExists = page.locator('//div[@class="login-wrapper1"]');
  const loginPageImageBoundingBox = await loginPageImageExists.boundingBox();
  console.log("Sony XYZ Creation Suite Bounding Box Dimenions::=", loginPageImageBoundingBox);
  const loginPageImageWidth = loginPageImageBoundingBox?.width;
  const loginPageImageHeight = loginPageImageBoundingBox?.height;
  console.log("Sony XYZ Creation Suite Dimenions Width::=", loginPageImageWidth);
    console.log("Sony XYZ Creation Suite Dimenions Height::=", loginPageImageHeight);

  await expect(loginPageImageWidth).toBe(loginImageData.width);
  await expect(loginPageImageHeight).toBe(loginImageData.height);

  if (loginPageImageBoundingBox) {
    console.log("Sony Login WebPage Image Dimenions:: ");
    console.log("Sony Login Webpage Image Dimenions Width::=", loginPageImageWidth);
    console.log("Sony Login Webpage Dimenions Height::=", loginPageImageHeight);

  } else {
    console.log("Sony Login Webpage Image is not visible or not Loaded");
  }

  const fontcolor = await loginPageImageExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(loginImageData.fontFamily);
  await expect(fontcolor.fontSize).toBe(loginImageData.fontSize);
  await expect(fontcolor.color).toBe(loginImageData.color);

    
     
});

test('Verify Login WebPage Welcome Image And Welcome Image Daimentions',async({page}) => {

  const welcomeImageData = welcomeImageJsonFile;
  console.log('read Json data::=', welcomeImageData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();
  const welcomeImageExists = page.locator('//img[@alt="welcome"]');
  const welcomeImageBoundingBox = await welcomeImageExists.boundingBox();
  console.log("Sony Login WelCome Image Bounding Box Dimenions::=", welcomeImageBoundingBox);
  const welcomeImageWidth = welcomeImageBoundingBox?.width;
  const welcomeImageHeight = welcomeImageBoundingBox?.height;
  console.log("Sony Login Welcome Image Dimentions Width::=", welcomeImageWidth);
    console.log("Sony Login Welcome Image Dimentions Height::=", welcomeImageHeight);

  await expect(welcomeImageWidth).toBe(welcomeImageData.width);
  await expect(welcomeImageHeight).toBe(welcomeImageData.height);

  if (welcomeImageBoundingBox) {
    console.log("Sony Login Welcome Image Dimensions:: ");
    console.log("Sony Login Welcome Image Dimensions Width::=", welcomeImageWidth);
    console.log("Sony Login Welcome Dimensions Height::=", welcomeImageHeight);

  } else {
    console.log("Sony Login Welcome Image is not visible or not Loaded");
  }

  // Font and Color
  const fontcolor = await welcomeImageExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(welcomeImageData.fontFamily);
  await expect(fontcolor.fontSize).toBe(welcomeImageData.fontSize);
  await expect(fontcolor.color).toBe(welcomeImageData.color);

    
     
});

test('Verify Login WebPage Welcome Label And Welcome label Daimention',async({page}) => {

  const welcomeMessageData = welcomeMessageJsonFile
  console.log('read Json data::=', welcomeMessageData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();
  const welcomeMessageExists = page.locator('//div[@class="welcome-message"]');
  const welcomeMessageBoundingBox = await welcomeMessageExists.boundingBox();
  console.log("Sony Login Welcome Message Bounding Box Dimentions::=", welcomeMessageBoundingBox);
  const welcomeMessageWidth = welcomeMessageBoundingBox?.width;
  const welcomeMessageHeight = welcomeMessageBoundingBox?.height;
  console.log("Sony Login Welcome Message Dimentions Width::=", welcomeMessageWidth);
  console.log("Sony Login Welcome Message Dimentions Height::=", welcomeMessageHeight);

  await expect(welcomeMessageWidth).toBe(welcomeMessageData.width);
  await expect(welcomeMessageHeight).toBe(welcomeMessageData.height);

  if (welcomeMessageBoundingBox) {
    console.log("Sony Login Welcome Message Dimentions:: ");
    console.log("Sony Login Welcome Message Dimentions Width::=", welcomeMessageWidth);
    console.log("Sony Login Welcome Message Dimentions Height::=", welcomeMessageHeight);

  } else {
    console.log("Sony Login Welcome Message is not visible or not Loaded");
  }

  // Font and Color
  const fontcolor = await welcomeMessageExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  
  await expect(fontcolor.fontFamily).toBe(welcomeMessageData.fontFamily);
  await expect(fontcolor.fontSize).toBe(welcomeMessageData.fontSize);
  await expect(fontcolor.color).toBe(welcomeMessageData.color);
    
     
});

test('Verify UserName Field Dimentions & UserName Text Field is Desable in Login WebPage',async({page}) => {

  const userNameTextBoxData = userNameJsonFile;
  console.log('read Json data::=', userNameTextBoxData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();
  const userNameTextboxExists = page.locator('//*[@id="userid"]');
  const userNameTextboxBoundingBox = await userNameTextboxExists.boundingBox();
  console.log("Sony Login UserName Field Bounding Box Dimentions::=", userNameTextboxBoundingBox);
  const userNameTextBoxWidth = userNameTextboxBoundingBox?.width;
  const userNameTextBoxHeight = userNameTextboxBoundingBox?.height;
  console.log("Sony Login UserName Field Dimentions Width::=", userNameTextBoxWidth);
  console.log("Sony Login UserName Field Dimentions Height::=", userNameTextBoxHeight);

  await expect(userNameTextBoxWidth).toBe(userNameTextBoxData.width);
  await expect(userNameTextBoxHeight).toBe(userNameTextBoxData.height);

  if (userNameTextboxBoundingBox) {
    console.log("Sony Login UserName Field Dimentions:: ");
    console.log("Sony Login UserName Field Dimentions Width::=", userNameTextBoxWidth);
    console.log("Sony Login UserName Field Dimentions Height::=", userNameTextBoxHeight);

  } else {
    console.log("Sony Login UserName Field is not visible or not Loaded");
  }

  const fontcolor = await userNameTextboxExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(userNameTextBoxData.fontFamily);
  await expect(fontcolor.fontSize).toBe(userNameTextBoxData.fontSize);
  await expect(fontcolor.color).toBe(userNameTextBoxData.color);
    
     
});

test('Verify Password Field Dimentions & Password Text Field is Desable in Login WebPage',async({page}) => {

  const passwordTextBoxData = passwordJsonFile;
  console.log('read Json data::=', passwordTextBoxData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();
  const passwordTextboxExists = page.locator('//*[@id="password"]');
  const passwordTextboxBoundingBox = await passwordTextboxExists.boundingBox();
  console.log("Sony Login Password Field Bounding Box Dimentions::=", passwordTextboxBoundingBox);
  const passwordTextBoxWidth = passwordTextboxBoundingBox?.width;
  const passwordTextBoxHeight = passwordTextboxBoundingBox?.height;
  console.log("Sony Login Password Field Dimentions Width::=", passwordTextBoxWidth);
  console.log("Sony Login Password Field Dimentions Height::=", passwordTextBoxHeight);

  await expect(passwordTextBoxWidth).toBe(passwordTextBoxData.width);
  await expect(passwordTextBoxHeight).toBe(passwordTextBoxData.height);

  if (passwordTextboxBoundingBox) {
    console.log("Sony Login Password Field Dimentions:: ");
    console.log("Sony Login Password Field Dimentions Width::=", passwordTextBoxWidth);
    console.log("Sony Login Password Field Dimentions Height::=", passwordTextBoxHeight);

  } else {
    console.log("Sony Login Password Field is not visible or not Loaded");
  }

  const fontcolor = await passwordTextboxExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(passwordTextBoxData.fontFamily);
  await expect(fontcolor.fontSize).toBe(passwordTextBoxData.fontSize);
  await expect(fontcolor.color).toBe(passwordTextBoxData.color);
  
    
     
});

test('Verify Login Button Dimentions & Login Button is Desable in Login WebPage',async({page}) => {
  
  
  const loginDesableButtonData = loginDesableButtonJsonFile;
  console.log('read Json data::=', loginDesableButtonData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();
  const loginButtonDesableExists = page.locator('//button[@data-testid="Login"]');
  const loginButtonDesableBoundingBox = await loginButtonDesableExists.boundingBox();
  console.log("Sony Login webpage Login Button Field Bounding Box Dimentions::=", loginButtonDesableBoundingBox);
  const loginButtonDesableWidth = loginButtonDesableBoundingBox?.width;
  const loginButtonDesableHeight = loginButtonDesableBoundingBox?.height;
  console.log("Sony Login webpage Login Button Field Dimentions Width::=", loginButtonDesableWidth);
  console.log("Sony Login webpage Login Button Dimentions Height::=", loginButtonDesableHeight);

  await expect(loginButtonDesableWidth).toBe(loginDesableButtonData.width);
  await expect(loginButtonDesableHeight).toBe(loginDesableButtonData.height);

  if (loginButtonDesableBoundingBox) {
    console.log("Sony Login webpage Login Button Field Dimentions:: ");
    console.log("Sony Login webpage Login Button Field Dimentions Width::=", loginButtonDesableWidth);
    console.log("Sony Login webpage Login Button Field Dimentions Height::=", loginButtonDesableHeight);

  } else {
    console.log("Sony Login webpage Login Button Field is not visible or not Loaded");
  }

  const fontcolor = await loginButtonDesableExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(loginDesableButtonData.fontFamily);
  await expect(fontcolor.fontSize).toBe(loginDesableButtonData.fontSize);
  await expect(fontcolor.color).toBe(loginDesableButtonData.color);

    
     
});

test('Verify Sign in With Google Button in Sony Login Webpage And Sign in With Google Button Dimentions',async({page}) => {

  
  const signInWithGoogleButtonData = signInWithGoogleButtonJsonFile;
  console.log('read Json data::=', signInWithGoogleButtonData);
  await page.goto(sonyLoginPageURL);
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();
  const signInWithGoogleButtonExists = page.locator('//button[contains(text(),"Sign in with Google")]');
  const signInWithGoogleButtonBoundingBox = await signInWithGoogleButtonExists.boundingBox();
  console.log("Sony Login webpage Sign In With Google Login Button Field Bounding Box Dimentions::=", signInWithGoogleButtonBoundingBox);
  const signInWithGoogleButtonWidth = signInWithGoogleButtonBoundingBox?.width;
  const signInWithGoogleButtonHeight = signInWithGoogleButtonBoundingBox?.height;
  console.log("Sony Login webpage Sign In With Google Login Button Field Dimentions Width::=", signInWithGoogleButtonWidth);
  console.log("Sony Login webpage Sign In With Google Login Button Dimentions Height::=", signInWithGoogleButtonHeight);

  await expect(signInWithGoogleButtonWidth).toBe(signInWithGoogleButtonData.width);
  await expect(signInWithGoogleButtonHeight).toBe(signInWithGoogleButtonData.height);

  if (signInWithGoogleButtonBoundingBox) {
    console.log("Sony Login webpage Sign In With Google Login Button Field Dimentions:: ");
    console.log("Sony Login webpage Sign In With Google Login Button Field Dimentions Width::=", signInWithGoogleButtonWidth);
    console.log("Sony Login webpage Sign In With Google Login Button Field Dimentions Height::=", signInWithGoogleButtonHeight);

  } else {
    console.log("Sony Login webpage Sign In With Google Login Button Field is not visible or not Loaded");
  }

  const fontcolor = await signInWithGoogleButtonExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(signInWithGoogleButtonData.fontFamily);
  await expect(fontcolor.fontSize).toBe(signInWithGoogleButtonData.fontSize);
  await expect(fontcolor.color).toBe(signInWithGoogleButtonData.color);
     
});
