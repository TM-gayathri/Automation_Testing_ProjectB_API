import { test, expect } from '@playwright/test';
import sonyLogoJsonFile from './testData/homePageTestData/sonyLogo.json';
import sonyLoginbuttonJsonFile from './testData/homePageTestData/sonyHomePageLoginButton.json';
import sonyXYZCreationSuiteJsonFile from './testData/homePageTestData/sonyXYZCreationSuite.json';
import sonyXYZAPPServiceJsonFile from './testData/homePageTestData/sonyXYZAppService.json';
const sony3DHomePageURL = 'https://sonyxyzfrontend-test.azurewebsites.net/';
test('Verify Sony 3D Home Page URL And Title', async ({ page }) => {
  await page.goto(sony3DHomePageURL);
  const sonyHomePageURL = page.url();
  const imageSelector = '#root > div > header > img';
  await page.waitForSelector(imageSelector, { state: 'visible' });
  console.log("Sony 3D Creation Home Page URL::= " + sonyHomePageURL);
  expect(sonyHomePageURL).toBe(sony3DHomePageURL);
  await expect(page).toHaveTitle('XYZ Capture');


});
test('Verify XYZ All Tabs [Top, Product,App & Service,SDK,Whats New] is Showing in Sony 3D Home Page', async ({ page }) => {
  await page.goto(sony3DHomePageURL);

  await expect(page.getByText('Top')).toBeVisible();
  await expect(page.getByRole('list')).toContainText('Top');

  await expect(page.getByText('Product')).toBeVisible();
  await expect(page.getByRole('list')).toContainText('Product');

  await expect(page.locator('#selected')).toContainText('App & Service');

  await expect(page.getByText('SDK')).toBeVisible();
  await expect(page.getByRole('list')).toContainText('SDK');
  const lastTab = "What's New";
  await expect(page.getByText(lastTab)).toBeVisible();
  await expect(page.getByRole('list')).toContainText('What\'s New');

  const homepageTabList = await page.locator('.wrapper > ul');
  const tabs = await homepageTabList.locator('li');
  console.log("Home page Tabs::=",tabs);
  const tabCount = await tabs.count();
  console.log("Home Page Tabs Count ::=",tabCount);
  expect(tabCount).toBe(5);

  const expectedTabs = ['Top','Product','App & Service','SDK','What\'s New'];
  for(let i =0; i<tabCount; i++) {
    const tabText = await tabs.nth(i).textContent();
    expect(tabText?.trim()).toBe(expectedTabs[i]);
    
   }


}); 


test('Verify Sony Logo is Showing in Sony 3D Home Page And Sony Logo Dimensions', async ({ page }) => {
 const sonyLogoData = sonyLogoJsonFile;
  console.log('read Json data::=', sonyLogoData);
  await page.goto('https://sonyxyzfrontend-test.azurewebsites.net/');
  const imageSelector = '#root > div > header > img';
  await page.waitForSelector(imageSelector, { state: 'visible' });
  console.log("Sony Image LOGO Present in the page");
  const imgSrc = await page.getAttribute(imageSelector, 'src');
  console.log(imgSrc);
  if (imgSrc == '/static/media/sony-logo.793747a6e91237b8077ec0576d61e364.svg') {
    console.log("Sony Logo is Showing");
  } else {
    console.log("Sony Logo is Not Showing");
  }

  const sonyLogoExists = page.locator('//img[@alt="logo"][1]');
  const sonyLogoBoundingBox = await sonyLogoExists.boundingBox();
  const sonyLogoWidth = sonyLogoBoundingBox?.width;
  const sonyLogoHeight = sonyLogoBoundingBox?.height;

  await expect(sonyLogoWidth).toBe(sonyLogoData.width);
  await expect(sonyLogoHeight).toBe(sonyLogoData.height);
  if (sonyLogoBoundingBox) {
    console.log("Sony Logo Dimensions::= ");
    console.log("Sony Logo Dimensions Width::=", sonyLogoWidth);
    console.log("Sony Logo Dimensions Height::=", sonyLogoHeight);

  } else {
    console.log("Sony Logo is not visible or not Loaded");
  }
  const fontcolor = await sonyLogoExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);

  await expect(fontcolor.fontFamily).toBe(sonyLogoData.fontFamily);
  await expect(fontcolor.fontSize).toBe(sonyLogoData.fontSize);
  await expect(fontcolor.color).toBe(sonyLogoData.color);

});



test('Verify Login Button is Showing in Sony 3D Home Page And Login Button Dimensions', async ({ page }) => {
 
  const sonyLoginbuttonData = sonyLoginbuttonJsonFile;
  console.log('read Json data::=', sonyLoginbuttonData);
  await page.goto(sony3DHomePageURL);
  const imageSelector = '#root > div > header > img';
  await page.waitForSelector(imageSelector, { state: 'visible' });
  const loginButton = page.getByRole('button', { name: 'Login' });
  await expect(loginButton).toBeVisible();
  const sonyLoginButton = page.locator('//button[@class="primary"]');
  const sonyLoginButtonBoundingBox = await sonyLoginButton.boundingBox();
  const sonyLoginButtonWidth = sonyLoginButtonBoundingBox?.width;
  const sonyLoginButonHeight = sonyLoginButtonBoundingBox?.height;

  await expect(sonyLoginButtonWidth).toBe(sonyLoginbuttonData.width);
  await expect(sonyLoginButonHeight).toBe(sonyLoginbuttonData.height);
  if (sonyLoginButtonBoundingBox) {
    console.log("Sony Login Button Dimentions:: ");
    console.log("Sony Login Button Dimentions Width::=", sonyLoginButtonWidth);
    console.log("Sony Login Button Dimentions Height::=", sonyLoginButonHeight);

  } else {
    console.log("Sony Login Button is not visible or not Loaded");
  }

  const fontcolor = await sonyLoginButton.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };
    

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(sonyLoginbuttonData.fontFamily);
  await expect(fontcolor.fontSize).toBe(sonyLoginbuttonData.fontSize);
  await expect(fontcolor.color).toBe(sonyLoginbuttonData.color);


});
test('Verify XYZ Creation Suite logo is Showing in Sony 3D Home Page and XYZ Creation Suite logo Dimentions', async ({ page }) => {
 
  const sonyXYZCreationSuiteImageData = sonyXYZCreationSuiteJsonFile;
  console.log('read Json data::=', sonyXYZCreationSuiteImageData);
  await page.goto(sony3DHomePageURL);
  const imageSelector = '#root > div > header > img';
  await page.waitForSelector(imageSelector, { state: 'visible' });
  await expect(page.getByText('XYZ Creation Suite')).toBeVisible();

  const xyzCreationSuiteTextExists = page.locator('//span[@class="heading" and text()= "XYZ Creation Suite"]');
  const xyzCreationSuiteTextBoundingBox = await xyzCreationSuiteTextExists.boundingBox();

  const sonyXYZCreationSuiteImageWidth = xyzCreationSuiteTextBoundingBox?.width;
  const sonyXYZCreationSuiteImageHeight = xyzCreationSuiteTextBoundingBox?.height;

  await expect(sonyXYZCreationSuiteImageWidth).toBe(sonyXYZCreationSuiteImageData.width);
  await expect(sonyXYZCreationSuiteImageHeight).toBe(sonyXYZCreationSuiteImageData.height);

  if (xyzCreationSuiteTextBoundingBox) {
    console.log("Sony XYZ Creation Suite Text Dimentions:: ");
    console.log("Sony XYZ Creation Suite Dimentions Width::=", sonyXYZCreationSuiteImageWidth);
    console.log("Sony XYZ Creation Suite Dimentions Height::=", sonyXYZCreationSuiteImageHeight);

  } else {
    console.log("Sony XYZ Creation Suite is not visible or not Loaded");
  }
  const fontcolor = await xyzCreationSuiteTextExists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(sonyXYZCreationSuiteImageData.fontFamily);
  await expect(fontcolor.fontSize).toBe(sonyXYZCreationSuiteImageData.fontSize);
  await expect(fontcolor.color).toBe(sonyXYZCreationSuiteImageData.color);


});

test('Verify XYZ App & Service Image logo is Showing in Sony 3D Home Page And XYZ App & Service Image logo Dimentions', async ({ page }) => {

  const sonyXYZAPPServiceData = sonyXYZAPPServiceJsonFile;
  console.log('read Json data::=', sonyXYZAPPServiceData);
  await page.goto(sony3DHomePageURL);
  const imageXYZ_AppService = '#root > div > div.color-header-portal';
  await page.waitForSelector(imageXYZ_AppService, { state: 'visible' });
  await expect(page.getByText('XYZ App & Service')).toBeVisible();
 

  const xyz_App_Service_Image_Exists = page.locator('//div[@class="color-header-portal"]');
  const xyz_App_Service_Image_BoundingBox = await xyz_App_Service_Image_Exists.boundingBox();

  const xyz_App_Service_Image_Width = xyz_App_Service_Image_BoundingBox?.width;
  const xyz_App_Service_Image_Height = xyz_App_Service_Image_BoundingBox?.height;

  await expect(xyz_App_Service_Image_Width).toBe(sonyXYZAPPServiceData.width);
  await expect(xyz_App_Service_Image_Height).toBe(sonyXYZAPPServiceData.height);

  if (xyz_App_Service_Image_BoundingBox) {
    console.log("Sony XYZ Creation Suite Text Dimentions:: ");
    console.log("Sony XYZ Creation Suite Dimentions Width::=", xyz_App_Service_Image_Width);
    console.log("Sony XYZ Creation Suite Dimentions Height::=", xyz_App_Service_Image_Height);

  } else {
    console.log("Sony XYZ Creation Suite is not visible or not Loaded");
  }
  const fontcolor = await xyz_App_Service_Image_Exists.evaluate((Element) => {
    const style = window.getComputedStyle(Element);
    console.log("Windows elements::= ",style);
    return {
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      color: style.color
      
    };

  });
  console.log("fontFamily::= ", fontcolor.fontFamily);
  console.log("fontSize::= ", fontcolor.fontSize);
  console.log("text color::= ", fontcolor.color);
  await expect(fontcolor.fontFamily).toBe(sonyXYZAPPServiceData.fontFamily);
  await expect(fontcolor.fontSize).toBe(sonyXYZAPPServiceData.fontSize);
  await expect(fontcolor.color).toBe(sonyXYZAPPServiceData.color);



});

